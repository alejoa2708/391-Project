
#Packages
library(tidyverse)
library(dplyr)
library(ggplot2)
library(randomForest)
library(rpart.plot)
library(cluster)    # clustering algorithms
library(factoextra) # clustering algorithms & visualization

#Read in the files
stats <- read_csv("stats.csv")
#results <- read_csv("results.csv")

#Bin the wins to get best from med from worst
stats_extra <- stats %>% mutate (win_bin = ntile(wins, 4))
sample_stats <- sample_n(stats, 60)

Stats_cor <- cor(stats[,2:41],use = "complete.obs")
round(Stats_cor, 2)

# Check distribution of bins
win_bin_check <- as.numeric(stats_extra$win_bin)
hist(win_bin_check)

## Hierarchical Clustering##
#hc.data = stats[,2:41]
#test <- na.omit(hc.data)
# Ward’s Method #
#wardsmethod <- hclust(dist(scale(test)), "ward.D")
#clust <- cutree(wardsmethod, k = 5)
#plot(hclust(dist(scale(hc.data)), "ward.D"))

## Hierarchical Clustering##
#season2006 <- stats %>% filter(season == "2006-2007")
seasons <- list("2006-2007", "2007-2008", "2008-2009", "2009-2010", "2010-2011", "2011-2012", "2012-2013", "2013-2014", "2014-2015","2015-2016","2016-2017","2017-2018")

#Check the seasons available for clustering
table(stats$season)

summary(stats)

profiling<-cutree(wardsmethod,4) 
table=data.frame(hc.data,profiling)
table

# methods to assess
m <- c( "average", "single", "complete", "ward")
names(m) <- c( "average", "single", "complete", "ward")

# # function to compute coefficient
# ac <- function(x,df) {
#   agnes(x = df, method = x)$ac
# }


#visualization
# pretty self explanatory
for(i in seasons) {
  temp = stats %>% filter(season == i)
  temp = temp %>% column_to_rownames(., var = "team")
  wardsmethod <- hclust(dist(scale(temp[,1:40])), "complete")
  
  plot(wardsmethod,cex = 0.6, hang = -1, main = paste("Season of ",i))
  
  temp = temp[,1:40] %>% select_if(~ !any(is.na(.)))
  
  sub_grp <- cutree(wardsmethod, k = 4)
  temp = temp %>% mutate(cluster = sub_grp) 
  fviz_cluster(list(data = temp, cluster = sub_grp))
}

fviz_cluster_plot <- function(temp, i) {
  temp = stats %>% filter(season == seasons[i])
  temp = temp %>% column_to_rownames(., var = "team")
  wardsmethod <- hclust(dist(scale(temp[,1:40])), "complete")
  temp = temp[,1:40] %>% select_if(~ !any(is.na(.)))
  sub_grp <- cutree(wardsmethod, k = 4)
  temp = temp %>% mutate(cluster = sub_grp) 
  fviz_cluster(list(data = temp, cluster = sub_grp))
}

# visualization
clust_results_group_variable <- function(stats, i) {
  # pretty self explanatory
  for(j in 1:4) {
    temp = stats %>% filter(season == seasons[i])
    temp = temp %>% column_to_rownames(., var = "team")
    wardsmethod <- hclust(dist(scale(temp[,1:40])), "complete")
    temp = temp[,1:40] %>% select_if(~ !any(is.na(.)))
    sub_grp <- cutree(wardsmethod, k = 4)
    temp = temp %>% mutate(cluster = sub_grp) 
    temp = temp %>% filter(cluster== j)
    if(j%%4 == 1) par(mfrow = c(4, 5))
    plot(x = temp$wins, y = temp$interception, col = j,
         ylim = c(195, 875), xlab = "win", ylab = "int",pch = 16, cex = 1.3)
    plot(x = temp$wins, y = temp$touches, col = j,
         ylim = c(16770, 35135), xlab = "win", ylab = "touches",pch = 16, cex = .9)
    plot(x = temp$wins, y = temp$corner_taken, col = j,
         ylim = c(132, 312), xlab = "win", ylab = "corner_taken",pch = 16, cex = .9)
    plot(x = temp$wins, y = temp$outfielder_block, col = j,
         ylim = c(50, 225), xlab = "win", ylab = "outfielder_block",pch = 16, cex = .9)
    plot(x = temp$wins, y = temp$att_ibox_goal, col = j,
         ylim = c(12, 98), xlab = "win", ylab = "att_ibox_goal",pch = 16, cex = .9)
  }
}

#visualization
# pretty self explanatory
fviz_cluster_plot(stats, 1) # 06-07
fviz_cluster_plot(stats, 2) # 07-08
fviz_cluster_plot(stats, 3) # 08-09
fviz_cluster_plot(stats, 4) # 09-10
fviz_cluster_plot(stats, 5) # 10-11
fviz_cluster_plot(stats, 6) # 11-12
fviz_cluster_plot(stats, 7) # 12-13
fviz_cluster_plot(stats, 8) # 13-14
fviz_cluster_plot(stats, 9) # 14-15
fviz_cluster_plot(stats, 10) # 15-16
fviz_cluster_plot(stats, 11) # 16-17
fviz_cluster_plot(stats, 12) # 17-18


dev.off()
clust_results_group_variable(stats, 1)
